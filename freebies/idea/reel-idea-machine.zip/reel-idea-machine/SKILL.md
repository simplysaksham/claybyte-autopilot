---
name: reel-idea-machine
description: Generates scored short-form video ideas (Reels, Shorts, TikTok) tailored to a creator's niche, audience and past posts. Use when the user asks for reel ideas, content ideas, video ideas, hooks, a content calendar, or says "I don't know what to post".
---

# Reel Idea Machine

You turn a creator's niche into a batch of ready-to-film short-video ideas. Each idea has a hook, a format, a 3-beat outline and an honest score out of 10. You throw away weak ideas instead of padding the list.

## Step 0: Load the creator profile

Look for a file named `creator-profile.md` in the current folder or project.

- **If the file exists:** read it and skip to Step 1.
- **If it doesn't exist:** ask these 6 questions in ONE message, then save the answers to `creator-profile.md`.
  1. Niche, in one line (e.g. "AI tools for small agency owners")
  2. Who watches: age, job, and what they're struggling with
  3. What they should feel or do after watching (learn, laugh, buy, follow)
  4. Your format strengths: talking head, faceless, animation, screen recording, skits
  5. Paste your last 10 post captions or topics (or "new account")
  6. Language and tone (e.g. "English, casual, a bit savage")

If the user pasted analytics or their top posts, note which topics and hooks won. Weight future ideas toward those patterns.

## Step 1: Run the 7 idea engines

Generate at least 3 raw ideas per engine (21+ total) before you filter anything.

| # | Engine | What it produces | Example pattern |
|---|---|---|---|
| 1 | MYTHS | Belief the audience holds that is wrong | "Stop doing X, it's killing your Y" |
| 2 | MISTAKES | Common error and the fix | "3 mistakes every new X makes" |
| 3 | VERSUS | Two options compared, with a verdict | "X vs Y: I tested both for 7 days" |
| 4 | STORIES | Personal or client story with a turn | "This client almost fired me, until..." |
| 5 | NUMBERS | Data, cost, time saved, before/after | "This cut my editing time from 4h to 20m" |
| 6 | TOOLS | A tool, prompt, template or workflow | "Free tool that does X in one click" |
| 7 | HOT TAKES | Contrarian opinion you can defend | "Unpopular opinion: X is overrated" |

Rules for raw ideas:
- Each one must be specific to the niche. "Productivity tips" fails. "How agency owners lose 6 hours a week to client WhatsApp" passes.
- Never repeat a topic from the last-10-posts list unless it's a clear sequel ("Part 2" or a new angle).
- Read `ideas-log.md` if it exists, and never re-pitch an idea logged there.

## Step 2: Write a hook for each idea

The hook is the first 1–2 seconds, under 12 words. Use one of these formulas:

1. **Callout:** "If you [specific situation], stop scrolling."
2. **Negative:** "Stop [common action]. Do this instead."
3. **Number + result:** "[Number] [thing] that [specific result]."
4. **Curiosity gap:** "Nobody talks about why [surprising fact]."
5. **Proof first:** "This [thing] got [result]. Here's how."
6. **Versus:** "[A] vs [B]. One clear winner."
7. **Confession:** "I wasted [time/money] on [thing] so you don't have to."
8. **Challenge:** "Bet you can't [task] without [thing]."

Also write the on-screen text hook: 3–6 words that work with the sound off.

## Step 3: Score every idea out of 10

Score honestly, 0–2 points per line:

- **Hook strength (0–2):** Would the target viewer stop scrolling in under 2 seconds?
- **Specificity (0–2):** Concrete numbers, names and situations, or vague?
- **Payoff (0–2):** Does the viewer get a clear result, answer or laugh by the end?
- **Shareability (0–2):** Would someone send it to a friend or save it?
- **Doability (0–2):** Can this creator film it today with their stated format?

**Keep only ideas scoring 7 or more.** Bin the rest, and show the binned ones as a single line each with the reason, so the user learns what makes ideas weak.

## Step 4: Output format

Give the kept ideas sorted by score, highest first. Use this exact format for each one:

```
### [Score]/10 — [Working title]
Engine: [engine]   Format: [talking head / skit / faceless / screen rec]   Length: [15/30/45s]
Hook (spoken): "..."
Hook (on-screen): "..."
Beat 1 (0–3s): ...
Beat 2: ...
Beat 3: ...
Payoff / CTA: ...
Caption first line: ...
Comment keyword (optional): ...
```

After the list, add:
- **Top pick for today:** one idea and a single sentence on why.
- **Binned:** one line per rejected idea with its score and reason.

## Step 5: Log it

Append every kept idea's title and today's date to `ideas-log.md`, so future runs never repeat it. If the user tells you which ideas they filmed and how they performed, write that next to the idea. Use it to weight future engines.

## Modes

- **"30 ideas" / "monthly":** run the engines 2x, keep the top 30, and arrange them into a 30-day calendar table (Day | Title | Engine | Hook). Rotate engines so no engine repeats on consecutive days.
- **"Daily" / "today":** produce 5 kept ideas plus the top pick only.
- **"Hooks for [topic]":** skip the engines and write 10 hooks for that topic using all 8 formulas, scored.
- **"Remix [link or caption]":** take a viral post the user shares and produce 5 original angles on it for their niche. Never copy its script.

## Quality bar

- No generic advice. Every idea needs a real situation, number, tool or story.
- No clickbait the video can't pay off.
- Write hooks in the user's language and tone from the profile.
- If the niche is too broad to give specific ideas, say so and suggest 3 narrower sub-niches before generating anything.
