# Creator profile

Niche (one line):
Who watches (age, job, struggle):
What they should feel/do after watching:
My formats (talking head / faceless / animation / screen rec / skits):
Language + tone:

## Last 10 posts
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.

## What worked (top posts + why)
-
